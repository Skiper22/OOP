#pragma once

#include <cstdio>

#include "points.h"
#include "edges.h"
#include "event_type.h"
#include "error.h"

typedef struct
{
    point_t center;
    points_t points;
    edges_t edges;
} figure_t;

figure_t &figure_init();

void free_figure(figure_t &figure);

error_t read_figure(figure_t &figure, FILE *fin);

error_t load_figure(figure_t &figure, const char *filename);

error_t move_figure(figure_t &figure, const move_t &move);

error_t scale_figure(figure_t &figure, const scale_t &scale);

error_t rotate_figure(figure_t &figure, const rotate_t &rotate);
