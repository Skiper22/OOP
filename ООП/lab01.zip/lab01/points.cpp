#include "points.h"

void points_init(points_t &points)
{
    points.array = nullptr;
    points.size = 0;
}

error_t allocate_points(points_t &points)
{
    error_t rc = SUCCESS;
    if (points.size <= 0)
        rc = SIZE_POINTS_ERROR;
    else
    {
        point_t *temp_array = (point_t *) malloc(points.size * sizeof(point_t));
        if (!temp_array)
            rc = MEMORY_ALLOCATE_ERROR;
        else
            points.array = temp_array;
    }

    return rc;
}

void free_points(points_t &points)
{
    free(points.array);
    points_init(points);
}

error_t init_points_size(points_t &points, FILE *fin)
{
    return read_points_count(points.size, fin);
}

error_t read_points(points_t &points, FILE *fin)
{
    if (fin == nullptr)
        return FILE_OPEN_ERROR;

    error_t rc = init_points_size(points, fin);
    if (!rc)
    {
        rc = allocate_points(points);
        if (!rc)
        {
            rc = read_all_points(points, fin);
            if (rc)
                free_points(points);
        }
    }
    return rc;
}

error_t read_points_count(int &size, FILE *fin)
{
    error_t rc = SUCCESS;
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else if (fscanf(fin, "%d", &size) != 1)
        rc = READ_FILE_ERROR;
    else if (size <= 0)
        rc = SIZE_POINTS_ERROR;

    return rc;
}

error_t read_all_points(points_t &points, FILE *fin)
{
    error_t rc = SUCCESS;
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else if (points.size <= 0)
        rc = SIZE_POINTS_ERROR;
    else if (!points.array)
        rc = MEMORY_ALLOCATE_ERROR;
    else
        for (int i = 0; rc == SUCCESS && i < points.size; i++)
            rc = read_point(points.array[i], fin);

    return rc;
}

error_t move_points(points_t &points, const move_t &coeff)
{
    if (!points.array)
        return FIGURE_NOT_LOADED;

    for (int i = 0; i < points.size; i++)
        move_point(points.array[i], coeff);

    return SUCCESS;
}

error_t rotate_points(points_t &points, const point_t &r_center, const rotate_t &coeff)
{
    if (!points.array)
        return FIGURE_NOT_LOADED;

    for (int i = 0; i < points.size; i++)
        rotate_point(points.array[i], r_center, coeff);

    return SUCCESS;
}

error_t scale_points(points_t &points, const point_t &s_center, const scale_t &coeff)
{
    error_t rc = SUCCESS;
    if (!points.array)
        rc = FIGURE_NOT_LOADED;
    else if (coeff.kx == 0 || coeff.ky == 0 || coeff.kz == 0)
        rc = COEFF_SCALE_ERROR;
    else
        for (int i = 0; i < points.size; i++)
            scale_point(points.array[i], s_center, coeff);

    return rc;
}
