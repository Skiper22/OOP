#include "figure.h"

figure_t &figure_init()
{
    static figure_t figure;

    figure.center.x = 0.0;
    figure.center.y = 0.0;
    figure.center.z = 0.0;

    points_init(figure.points);
    edges_init(figure.edges);

    return figure;
}

void free_figure(figure_t &figure)
{
    free_points(figure.points);
    free_edges(figure.edges);
}

error_t read_figure(figure_t &figure, FILE *fin)
{
    if (fin == nullptr)
        return FILE_OPEN_ERROR;

    figure = figure_init();

    error_t rc = read_points(figure.points, fin);
    if (rc == SUCCESS)
    {
        rc = read_edges(figure.edges, fin);
        if (rc)
            free_points(figure.points);
    }

    return rc;
}

error_t load_figure(figure_t &figure, const char *filename)
{
    if (filename == nullptr)
        return FILE_OPEN_ERROR;

    error_t rc;
    FILE *fin = fopen(filename, "r");
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else
    {
        figure_t current_figure;

        rc = read_figure(current_figure, fin);
        fclose(fin);
        if (rc == SUCCESS)
        {
            free_figure(figure);
            figure = current_figure;
        }

    }
    return rc;
}

error_t move_figure(figure_t &figure, const move_t &move)
{
    move_point(figure.center, move);
    return move_points(figure.points, move);
}

error_t scale_figure(figure_t &figure, const scale_t &scale)
{
    return scale_points(figure.points, figure.center, scale);
}

error_t rotate_figure(figure_t &figure, const rotate_t &rotate)
{
    return rotate_points(figure.points, figure.center, rotate);
}
