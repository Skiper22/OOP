/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSave;
    QAction *actionLoad;
    QAction *actionInfFile;
    QAction *actionInfProgram;
    QAction *actionInfDeveloper;
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupMoving;
    QGridLayout *gridGroupMoving;
    QDoubleSpinBox *enterZMoving;
    QLabel *labelYMoving;
    QLabel *labelZMoving;
    QLabel *labelXMoving;
    QPushButton *move;
    QDoubleSpinBox *enterXMoving;
    QDoubleSpinBox *enterYMoving;
    QGroupBox *groupTurn;
    QGridLayout *gridGroupTurn;
    QLabel *labelZTurn;
    QLabel *labelYTurn;
    QDoubleSpinBox *enterZTurn;
    QLabel *labelXTurn;
    QDoubleSpinBox *enterYTurn;
    QDoubleSpinBox *enterXTurn;
    QPushButton *rotate;
    QGroupBox *groupScale;
    QGridLayout *gridGroupScale;
    QLabel *labelZScale;
    QDoubleSpinBox *enterZScale;
    QDoubleSpinBox *enterYScale;
    QLabel *labelYScale;
    QLabel *labelXScale;
    QDoubleSpinBox *enterXScale;
    QPushButton *scale;
    QGraphicsView *graphicsView;
    QStatusBar *statusbar;
    QMenuBar *menubar;
    QMenu *actionsFile;
    QMenu *actionsInformation;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1011, 672);
        MainWindow->setMinimumSize(QSize(1000, 672));
        MainWindow->setToolTipDuration(-6);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName("actionSave");
        actionLoad = new QAction(MainWindow);
        actionLoad->setObjectName("actionLoad");
        actionInfFile = new QAction(MainWindow);
        actionInfFile->setObjectName("actionInfFile");
        actionInfProgram = new QAction(MainWindow);
        actionInfProgram->setObjectName("actionInfProgram");
        actionInfDeveloper = new QAction(MainWindow);
        actionInfDeveloper->setObjectName("actionInfDeveloper");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setToolTipDuration(-1);
        centralwidget->setInputMethodHints(Qt::ImhNone);
        horizontalLayout_2 = new QHBoxLayout(centralwidget);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(50);
        verticalLayout->setObjectName("verticalLayout");
        groupMoving = new QGroupBox(centralwidget);
        groupMoving->setObjectName("groupMoving");
        groupMoving->setMinimumSize(QSize(249, 173));
        groupMoving->setMaximumSize(QSize(16777215, 173));
        QFont font;
        font.setPointSize(12);
        groupMoving->setFont(font);
        gridGroupMoving = new QGridLayout(groupMoving);
        gridGroupMoving->setObjectName("gridGroupMoving");
        gridGroupMoving->setHorizontalSpacing(15);
        gridGroupMoving->setVerticalSpacing(20);
        gridGroupMoving->setContentsMargins(10, 10, 10, 10);
        enterZMoving = new QDoubleSpinBox(groupMoving);
        enterZMoving->setObjectName("enterZMoving");
        enterZMoving->setMinimum(-1000.000000000000000);
        enterZMoving->setMaximum(1000.000000000000000);

        gridGroupMoving->addWidget(enterZMoving, 1, 2, 1, 1);

        labelYMoving = new QLabel(groupMoving);
        labelYMoving->setObjectName("labelYMoving");
        QFont font1;
        font1.setPointSize(14);
        labelYMoving->setFont(font1);

        gridGroupMoving->addWidget(labelYMoving, 0, 1, 1, 1);

        labelZMoving = new QLabel(groupMoving);
        labelZMoving->setObjectName("labelZMoving");
        labelZMoving->setFont(font1);

        gridGroupMoving->addWidget(labelZMoving, 0, 2, 1, 1);

        labelXMoving = new QLabel(groupMoving);
        labelXMoving->setObjectName("labelXMoving");
        labelXMoving->setFont(font1);

        gridGroupMoving->addWidget(labelXMoving, 0, 0, 1, 1);

        move = new QPushButton(groupMoving);
        move->setObjectName("move");

        gridGroupMoving->addWidget(move, 2, 0, 1, 3);

        enterXMoving = new QDoubleSpinBox(groupMoving);
        enterXMoving->setObjectName("enterXMoving");
        enterXMoving->setMinimum(-1000.000000000000000);
        enterXMoving->setMaximum(1000.000000000000000);
        enterXMoving->setValue(50.000000000000000);

        gridGroupMoving->addWidget(enterXMoving, 1, 0, 1, 1);

        enterYMoving = new QDoubleSpinBox(groupMoving);
        enterYMoving->setObjectName("enterYMoving");
        enterYMoving->setMinimum(-1000.000000000000000);
        enterYMoving->setMaximum(1000.000000000000000);

        gridGroupMoving->addWidget(enterYMoving, 1, 1, 1, 1);


        verticalLayout->addWidget(groupMoving);

        groupTurn = new QGroupBox(centralwidget);
        groupTurn->setObjectName("groupTurn");
        groupTurn->setMinimumSize(QSize(249, 173));
        groupTurn->setMaximumSize(QSize(16777215, 173));
        groupTurn->setFont(font);
        gridGroupTurn = new QGridLayout(groupTurn);
        gridGroupTurn->setObjectName("gridGroupTurn");
        gridGroupTurn->setHorizontalSpacing(15);
        gridGroupTurn->setVerticalSpacing(20);
        gridGroupTurn->setContentsMargins(10, 10, 10, 10);
        labelZTurn = new QLabel(groupTurn);
        labelZTurn->setObjectName("labelZTurn");
        labelZTurn->setFont(font1);

        gridGroupTurn->addWidget(labelZTurn, 0, 2, 1, 1);

        labelYTurn = new QLabel(groupTurn);
        labelYTurn->setObjectName("labelYTurn");
        labelYTurn->setFont(font1);

        gridGroupTurn->addWidget(labelYTurn, 0, 1, 1, 1);

        enterZTurn = new QDoubleSpinBox(groupTurn);
        enterZTurn->setObjectName("enterZTurn");
        enterZTurn->setMinimum(-1000.000000000000000);
        enterZTurn->setMaximum(1000.000000000000000);

        gridGroupTurn->addWidget(enterZTurn, 1, 2, 1, 1);

        labelXTurn = new QLabel(groupTurn);
        labelXTurn->setObjectName("labelXTurn");
        labelXTurn->setFont(font1);

        gridGroupTurn->addWidget(labelXTurn, 0, 0, 1, 1);

        enterYTurn = new QDoubleSpinBox(groupTurn);
        enterYTurn->setObjectName("enterYTurn");
        enterYTurn->setMinimum(-1000.000000000000000);
        enterYTurn->setMaximum(1000.000000000000000);

        gridGroupTurn->addWidget(enterYTurn, 1, 1, 1, 1);

        enterXTurn = new QDoubleSpinBox(groupTurn);
        enterXTurn->setObjectName("enterXTurn");
        enterXTurn->setMinimum(-1000.000000000000000);
        enterXTurn->setMaximum(1000.000000000000000);
        enterXTurn->setValue(30.000000000000000);

        gridGroupTurn->addWidget(enterXTurn, 1, 0, 1, 1);

        rotate = new QPushButton(groupTurn);
        rotate->setObjectName("rotate");

        gridGroupTurn->addWidget(rotate, 2, 0, 1, 3);


        verticalLayout->addWidget(groupTurn);

        groupScale = new QGroupBox(centralwidget);
        groupScale->setObjectName("groupScale");
        groupScale->setMaximumSize(QSize(16777215, 166));
        groupScale->setFont(font);
        gridGroupScale = new QGridLayout(groupScale);
        gridGroupScale->setObjectName("gridGroupScale");
        gridGroupScale->setHorizontalSpacing(15);
        gridGroupScale->setVerticalSpacing(20);
        gridGroupScale->setContentsMargins(10, 10, 10, 10);
        labelZScale = new QLabel(groupScale);
        labelZScale->setObjectName("labelZScale");
        labelZScale->setFont(font1);

        gridGroupScale->addWidget(labelZScale, 0, 2, 1, 1);

        enterZScale = new QDoubleSpinBox(groupScale);
        enterZScale->setObjectName("enterZScale");
        enterZScale->setMinimum(-1000.000000000000000);
        enterZScale->setMaximum(1000.000000000000000);
        enterZScale->setValue(1.000000000000000);

        gridGroupScale->addWidget(enterZScale, 1, 2, 1, 1);

        enterYScale = new QDoubleSpinBox(groupScale);
        enterYScale->setObjectName("enterYScale");
        enterYScale->setMinimum(-1000.000000000000000);
        enterYScale->setMaximum(1000.000000000000000);
        enterYScale->setValue(1.000000000000000);

        gridGroupScale->addWidget(enterYScale, 1, 1, 1, 1);

        labelYScale = new QLabel(groupScale);
        labelYScale->setObjectName("labelYScale");
        labelYScale->setFont(font1);

        gridGroupScale->addWidget(labelYScale, 0, 1, 1, 1);

        labelXScale = new QLabel(groupScale);
        labelXScale->setObjectName("labelXScale");
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setStrikeOut(false);
        font2.setKerning(true);
        labelXScale->setFont(font2);
        labelXScale->setFrameShape(QFrame::NoFrame);
        labelXScale->setFrameShadow(QFrame::Plain);
        labelXScale->setLineWidth(1);
        labelXScale->setMidLineWidth(0);
        labelXScale->setTextFormat(Qt::PlainText);
        labelXScale->setScaledContents(false);
        labelXScale->setWordWrap(false);
        labelXScale->setMargin(0);
        labelXScale->setIndent(-1);

        gridGroupScale->addWidget(labelXScale, 0, 0, 1, 1);

        enterXScale = new QDoubleSpinBox(groupScale);
        enterXScale->setObjectName("enterXScale");
        enterXScale->setMinimum(-1000.000000000000000);
        enterXScale->setMaximum(1000.000000000000000);
        enterXScale->setValue(2.000000000000000);

        gridGroupScale->addWidget(enterXScale, 1, 0, 1, 1);

        scale = new QPushButton(groupScale);
        scale->setObjectName("scale");
        QFont font3;
        font3.setPointSize(12);
        font3.setBold(false);
        font3.setItalic(false);
        scale->setFont(font3);

        gridGroupScale->addWidget(scale, 2, 0, 1, 3);


        verticalLayout->addWidget(groupScale);


        horizontalLayout_2->addLayout(verticalLayout);

        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName("graphicsView");
        graphicsView->setMinimumSize(QSize(665, 612));

        horizontalLayout_2->addWidget(graphicsView);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1011, 24));
        actionsFile = new QMenu(menubar);
        actionsFile->setObjectName("actionsFile");
        actionsInformation = new QMenu(menubar);
        actionsInformation->setObjectName("actionsInformation");
        MainWindow->setMenuBar(menubar);

        menubar->addAction(actionsFile->menuAction());
        menubar->addAction(actionsInformation->menuAction());
        actionsFile->addSeparator();
        actionsFile->addSeparator();
        actionsFile->addAction(actionLoad);
        actionsInformation->addAction(actionInfFile);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionSave->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214", nullptr));
        actionLoad->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214 \321\204\320\270\320\263\321\203\321\200\321\203", nullptr));
        actionInfFile->setText(QCoreApplication::translate("MainWindow", "\320\236 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\265", nullptr));
        actionInfProgram->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\260", nullptr));
        actionInfDeveloper->setText(QCoreApplication::translate("MainWindow", "\320\240\320\260\320\267\321\200\320\260\320\261\320\276\321\202\321\207\320\270\320\272", nullptr));
        groupMoving->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\265\320\275\320\276\321\201", nullptr));
        labelYMoving->setText(QCoreApplication::translate("MainWindow", "dy", nullptr));
        labelZMoving->setText(QCoreApplication::translate("MainWindow", "dz", nullptr));
        labelXMoving->setText(QCoreApplication::translate("MainWindow", "dx", nullptr));
        move->setText(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\265\320\275\320\265\321\201\321\202\320\270", nullptr));
        groupTurn->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\262\320\276\321\200\320\276\321\202", nullptr));
        labelZTurn->setText(QCoreApplication::translate("MainWindow", "angle z", nullptr));
        labelYTurn->setText(QCoreApplication::translate("MainWindow", "angle y", nullptr));
        labelXTurn->setText(QCoreApplication::translate("MainWindow", "angle x", nullptr));
        rotate->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\262\320\265\321\200\320\275\321\203\321\202\321\214", nullptr));
        groupScale->setTitle(QCoreApplication::translate("MainWindow", "\320\234\320\260\321\201\321\210\321\202\320\260\320\261\320\270\321\200\320\276\320\262\320\260\320\275\320\270\320\265", nullptr));
        labelZScale->setText(QCoreApplication::translate("MainWindow", "kz", nullptr));
        labelYScale->setText(QCoreApplication::translate("MainWindow", "ky", nullptr));
        labelXScale->setText(QCoreApplication::translate("MainWindow", "kx", nullptr));
        scale->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\276\320\274\320\260\321\201\321\210\321\202\320\260\320\261\320\270\321\200\320\276\320\262\320\260\321\202\321\214", nullptr));
        actionsFile->setTitle(QCoreApplication::translate("MainWindow", "\320\244\320\260\320\271\320\273", nullptr));
        actionsInformation->setTitle(QCoreApplication::translate("MainWindow", "\320\241\320\277\321\200\320\260\320\262\320\272\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
