#include "draw.h"

void map_scene_coordinates(points_t &points, const drawview_t &view)
{
    move_t move = {
        .dx = view.width / 2,
        .dy = view.height / 2,
        .dz = 0
    };
    move_points(points, move);
}

void unmap_scene_coordinates(points_t &points, const drawview_t &view)
{
    move_t move = {
        .dx = -view.width / 2,
        .dy = -view.height / 2,
        .dz = 0
    };
    move_points(points, move);
}

line_t get_points(const drawview_t &view, const edge_t &edge, const point_t *array_points)
{
    line_t line;

    line.p1 = array_points[edge.p1];
    line.p2 = array_points[edge.p2];

    return line;
}

error_t clear_scene(const drawview_t &view)
{
    if (!view.scene)
        return SCENE_WRONG_ERROR;

    view.scene->clear();
    return SUCCESS;
}

error_t draw_line(const drawview_t &view, const point_t &p1, const point_t &p2)
{
    if (!view.scene)
        return SCENE_WRONG_ERROR;

    view.scene->addLine(p1.x, p1.y, p2.x, p2.y);
    return SUCCESS;
}

error_t draw_mapped_lines(const drawview_t &view, points_t &points, const edges_t &edges)
{
    line_t line;
    error_t rc = SUCCESS;
    for (int i = 0; rc == SUCCESS && i < edges.size; i++)
    {
        line = get_points(view, edges.array[i], points.array);
        rc = draw_line(view, line.p1, line.p2);
    }

    return rc;
}

error_t draw_lines(const drawview_t &view, points_t &points, const edges_t &edges)
{
    error_t rc;
    if (points.array == nullptr || edges.array == nullptr)
        rc = MEMORY_ALLOCATE_ERROR;
    else if (!view.scene)
        rc = SCENE_WRONG_ERROR;
    else
    {
        map_scene_coordinates(points, view);
        rc = draw_mapped_lines(view, points, edges);
        unmap_scene_coordinates(points, view);
    }

    return rc;
}

error_t draw_figure(figure_t &figure, drawview_t &view)
{
    error_t rc = clear_scene(view);
    if (!rc)
        rc = draw_lines(view, figure.points, figure.edges);

    return rc;
}
