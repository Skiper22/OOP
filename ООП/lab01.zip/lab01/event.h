#pragma once

#include "figure.h"
#include "draw.h"
#include "event_type.h"
#include "error.h"

enum event
{
    LOAD,
    ROTATE,
    MOVE,
    SCALE,
    DRAW,
    QUIT
};

typedef struct
{
    enum event event;
    union
    {
        const char *filename;
        drawview_t view;
        rotate_t rotate;
        move_t move;
        scale_t scale;
    };
} request_t;

error_t handle_event_request(request_t &request);
