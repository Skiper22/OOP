#include "edges.h"

error_t allocate_edges(edges_t &edges)
{
    error_t rc = SUCCESS;
    if (edges.size <= 0)
        rc = SIZE_EDGES_ERROR;
    else
    {
        edge_t *temp_array = (edge_t *) malloc(edges.size * sizeof(edge_t));
        if (!temp_array)
            rc = MEMORY_ALLOCATE_ERROR;
        else
            edges.array = temp_array;
    }
    return rc;
}

void edges_init(edges_t &edges)
{
    edges.array = nullptr;
    edges.size = 0;
}

void free_edges(edges_t &edges)
{
    free(edges.array);
    edges_init(edges);
}

error_t read_edge(edge_t &edge, FILE *fin)
{
    error_t rc = SUCCESS;
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else if (fscanf(fin, "%d %d", &edge.p1, &edge.p2) != 2)
        rc = READ_FILE_ERROR;

    return rc;
}

error_t read_all_edges(edges_t &edges, FILE *fin)
{
    error_t rc = SUCCESS;
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else if (edges.size <= 0)
        rc = SIZE_EDGES_ERROR;
    else if (!edges.array)
        rc = MEMORY_ALLOCATE_ERROR;
    else
        for (int i = 0; rc == SUCCESS && i < edges.size; i++)
            rc = read_edge(edges.array[i], fin);

    return rc;
}

error_t read_edges_count(edges_t &edges, FILE *fin)
{
    error_t rc = SUCCESS;
    if (fin == nullptr)
        rc = FILE_OPEN_ERROR;
    else if (fscanf(fin, "%d", &edges.size) != 1)
        rc = READ_FILE_ERROR;
    else if (edges.size <= 0)
        rc = SIZE_POINTS_ERROR;

    return rc;
}

error_t read_edges(edges_t &edges, FILE *fin)
{
    if (fin == nullptr)
        return FILE_OPEN_ERROR;

    error_t rc;
    rc = read_edges_count(edges, fin);
    if (!rc)
    {
        rc = allocate_edges(edges);
        if (!rc)
        {
            rc = read_all_edges(edges, fin);
            if (rc)
                free_edges(edges);
        }
    }

    return rc;
}
