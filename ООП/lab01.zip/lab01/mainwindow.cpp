#include <QFileDialog>
#include <QMessageBox>
#include <iostream>

#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QGraphicsScene *scene = new QGraphicsScene(this);

    ui->graphicsView->setScene(scene);
    ui->graphicsView->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    ui->graphicsView->setStyleSheet("QGraphicsView {background-color: white}");

    connect(ui->actionLoad, &QAction::triggered, this,
            &MainWindow::on_load_clicked);

    connect(ui->actionInfFile, &QAction::triggered, this,
            &MainWindow::on_info_clicked);
}

MainWindow::~MainWindow()
{
    request_t request;
    request.event = QUIT;
    handle_event_request(request);
    delete ui;
}

error_t MainWindow::draw()
{
    auto content = ui->graphicsView->contentsRect();
    ui->graphicsView->scene()->setSceneRect(0, 0, content.width(),
                                            content.height());

    request_t request;
    request.event = DRAW;
    request.view = {.scene = ui->graphicsView->scene(),
                   .width =  ui->graphicsView->scene()->width(),
                   .height =  ui->graphicsView->scene()->height()
                   };

    return handle_event_request(request);
}

void MainWindow::on_load_clicked()
{
    QString path = QFileDialog::getOpenFileName();
    request_t request;
    request.event = LOAD;
    request.filename = path.toUtf8().data();

    error_t rc = handle_event_request(request);
    if (rc)
        error_message(rc);
    else
    {
        rc = draw();
        if (rc)
            error_message(rc);
    }
}

void MainWindow::on_info_clicked()
{
    QMessageBox::information(nullptr, "Справка", "Программа 3D Viewer\n"
                                      "Загружаемый файл должен содержать количество точек\n"
                                      "Затем идут координаты в порядке:\n"
                                      "x y z\n"
                                      "После ввода всех точек нужно отметить количество ребер\n"
                                      "Затем идет нумерация связи точек:\n"
                                      "точка1 точка2\n\n");
}

void MainWindow::on_move_clicked()
{
    request_t request;
    request.event = MOVE;
    request.move = {
           .dx = ui->enterXMoving->value(),
           .dy = ui->enterYMoving->value(),
           .dz = ui->enterZMoving->value()
    };

    error_t rc = handle_event_request(request);
    if (rc)
        error_message(rc);
    else
    {
        rc = draw();
        if (rc)
            error_message(rc);
    }
}

void MainWindow::on_rotate_clicked()
{
    request_t request;
    request.event = ROTATE;
    request.rotate = {
           .angle_x = ui->enterXTurn->value(),
           .angle_y = ui->enterYTurn->value(),
           .angle_z = ui->enterZTurn->value()
    };

    error_t rc = handle_event_request(request);
    if (rc)
        error_message(rc);
    else
    {
        rc = draw();
        if (rc)
            error_message(rc);
    }
}


void MainWindow::on_scale_clicked()
{
    request_t request;
    request.event = SCALE;
    request.scale = {
           .kx = ui->enterXScale->value(),
           .ky = ui->enterYScale->value(),
           .kz = ui->enterZScale->value()
    };

    error_t rc = handle_event_request(request);
    if (rc)
        error_message(rc);
    else
    {
        rc = draw();
        if (rc)
            error_message(rc);
    }
}
