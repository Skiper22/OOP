#pragma once

#include <cstdio>
#include <cstdlib>

#include "points.h"
#include "error.h"

typedef struct
{
    int p1;
    int p2;
} edge_t;

typedef struct
{
    edge_t *array;
    int size;
} edges_t;

error_t allocate_edges(edges_t &edges);

void free_edges(edges_t &edges);

void edges_init(edges_t &edges);

error_t read_edges_count(edges_t &edges, FILE *fin);

error_t read_edges(edges_t &edges, FILE *fin);

error_t read_all_edges(edges_t &edges, FILE *fin);

error_t read_edge(edge_t &edge, FILE *fin);
