#pragma once

#include <cstdio>
#include <cstdlib>

#include "point.h"
#include "error.h"

typedef struct
{
    point_t *array;
    int size;
} points_t;

void points_init(points_t &points);

error_t allocate_points(points_t &points);

void free_points(points_t &points);

error_t read_points(points_t &points, FILE *fin);

error_t read_points_count(int &size, FILE *fin);

error_t read_all_points(points_t &points, FILE *fin);

error_t move_points(points_t &points, const move_t &coeff);

error_t rotate_points(points_t &points, const point_t &r_center, const rotate_t &coeff);

error_t scale_points(points_t &points, const point_t &s_center, const scale_t &coeff);
