#pragma once

#include <QMessageBox>

typedef enum
{
    SUCCESS,
    FILE_OPEN_ERROR,
    READ_FILE_ERROR,
    FILE_CLOSE_ERROR,
    FILE_WRITE_ERROR,
    FIGURE_NOT_LOADED,
    SIZE_POINTS_ERROR,
    SIZE_EDGES_ERROR,
    SCENE_WRONG_ERROR,
    MEMORY_ALLOCATE_ERROR,
    COEFF_SCALE_ERROR,
    COMMAND_UNDEFINED
} error_t;

void error_message(error_t &error);
