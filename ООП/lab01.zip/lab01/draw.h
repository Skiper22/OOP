#pragma once

#include <QGraphicsScene>

#include "figure.h"
#include "points.h"

typedef struct
{
    QGraphicsScene *scene;
    double width;
    double height;
} drawview_t;

typedef struct
{
    point_t p1;
    point_t p2;
} line_t;

line_t get_points(const drawview_t &view, const edge_t &edge, const point_t *array_points);

error_t draw_line(const drawview_t &view, const point_t &p1, const point_t &p2);

error_t draw_lines(const drawview_t &view, points_t &points, const edges_t &edges);

error_t draw_figure(figure_t &figure, drawview_t &view);

error_t clear_scene(const drawview_t &view);
