#pragma once

#include <cstdio>
#include <cstdlib>
#include <cmath>

#include "event_type.h"
#include "error.h"

typedef struct
{
    double x;
    double y;
    double z;
} point_t;

error_t read_point(point_t &point, FILE *fin);

void move_point(point_t &point, const move_t &move);

void rotate_point(point_t &point, const point_t &r_center, const rotate_t &rotate);

void scale_point(point_t &point, const point_t &s_center, const scale_t &scale);
