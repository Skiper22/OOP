#pragma once

typedef struct
{
    double dx;
    double dy;
    double dz;
} move_t;

typedef struct
{
    double angle_x;
    double angle_y;
    double angle_z;
} rotate_t;

typedef struct
{
    double kx;
    double ky;
    double kz;
} scale_t;
